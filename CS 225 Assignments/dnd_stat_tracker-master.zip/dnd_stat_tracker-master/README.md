# dnd_stat_tracker

This was created in Mobaxterm. The a.out is the executable file and can be executed in mobaxterm.
